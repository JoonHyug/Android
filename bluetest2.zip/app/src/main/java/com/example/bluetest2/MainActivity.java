package com.example.bluetest2;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    TextView tv_status_;
    TextView tv_read_;
    Button btn_scan_;
    Button btn_stop_;
    Button btn_send_;
    Button btn_show_;

    private final static String TAG="Central";
    private final static int REQUEST_ENABLE_BT= 1;
    private final static int REQUEST_FINE_LOCATION= 2;
    private final static int SCAN_PERIOD= 5000;
    private BluetoothAdapter ble_adapter_;
    private boolean is_scanning_= false;
    private boolean connected_= false;
    private Map<String, BluetoothDevice> scan_results_;
    private ScanCallback scan_cb_;
    private BluetoothLeScanner ble_scanner_;
    private Handler scan_handler_;

    public static String SERVICE_STRING = "0000180A-F845-40FA-995D-658A43FEEA4C";
    public static UUID UUID_TDCS_SERVICE= UUID.fromString(SERVICE_STRING);
    public static String CHARACTERISTIC_COMMAND_STRING = "00002A98-F845-40FA-995D-658A43FEEA4C";
    public static UUID UUID_CTRL_COMMAND = UUID.fromString( CHARACTERISTIC_COMMAND_STRING );
    public static String CHARACTERISTIC_RESPONSE_STRING = "00002A9D-F845-40FA-995D-658A43FEEA4C";
    public static UUID UUID_CTRL_RESPONSE = UUID.fromString( CHARACTERISTIC_RESPONSE_STRING );
    public final static String MAC_ADDR= "AC:67:B2:2D:E3:0A";


    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_status_= findViewById( R.id.tv_status );
        tv_read_= findViewById( R.id.tv_read );
        btn_scan_= findViewById( R.id.btn_scan );
        btn_stop_= findViewById( R.id.btn_stop );
        btn_send_= findViewById( R.id.btn_send );
        btn_show_= findViewById( R.id.btn_show );
        ble_scanner_ = ble_adapter_.getBluetoothLeScanner();

        // ble manager
        BluetoothManager ble_manager;
        ble_manager= (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE );
        // set ble adapter
        ble_adapter_= ble_manager.getAdapter();

        btn_scan_.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                startScan(v);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();

        // finish app if the BLE is not supported
        if( !getPackageManager().hasSystemFeature( PackageManager.FEATURE_BLUETOOTH_LE ) ) {
            finish();
        }
    }

    /*
    Start BLE scan
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void startScan(View v ) {
        tv_status_.setText("Scanning...");
        // check ble adapter and ble enabled
        if (ble_adapter_ == null || !ble_adapter_.isEnabled()) {
            requestEnableBLE();
            tv_status_.setText("Scanning Failed: ble not enabled");
            return;
        }
        // check if location permission
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestLocationPermission();
            tv_status_.setText("Scanning Failed: no fine location permission");
            return;
        }
        // setup scan filters
        List<ScanFilter> filters = new ArrayList<>();
        // create a scan filter with device mac address
        ScanFilter scan_filter = new ScanFilter.Builder()
                .setDeviceAddress( MAC_ADDR )
                .build();
        // add the filter to the list
        filters.add( scan_filter );

        ScanSettings settings= new ScanSettings.Builder()
                .setScanMode( ScanSettings.SCAN_MODE_LOW_POWER )
                .build();

        scan_results_= new HashMap<>();
        scan_cb_= new BLEScanCallback( scan_results_ );

        //// now ready to scan
        // start scan
        Log.d(TAG, "\n"+filters+"\n"+settings+"\n"+ scan_cb_+"\n"+ble_scanner_);
        ble_scanner_.startScan( filters, settings, scan_cb_ );
        // set scanning flag
        is_scanning_= true;
    }

    /*
    Request BLE enable
    */
    private void requestEnableBLE() {
        Intent ble_enable_intent= new Intent( BluetoothAdapter.ACTION_REQUEST_ENABLE );
        startActivityForResult( ble_enable_intent, REQUEST_ENABLE_BT );

    }

    /*
    Request Fine Location permission
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void requestLocationPermission() {
        requestPermissions( new String[]{ Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_FINE_LOCATION );
    }
    /*
    BLE Scan Callback class
    */
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private class BLEScanCallback extends ScanCallback {
        private Map<String, BluetoothDevice> cb_scan_results_;

        /*
        Constructor
         */
        BLEScanCallback( Map<String, BluetoothDevice> _scan_results ) {
            cb_scan_results_= _scan_results;
        }

        @Override
        public void onScanResult( int _callback_type, ScanResult _result ) {
            Log.d( TAG, "onScanResult" );
            addScanResult( _result );
        }

        @Override
        public void onBatchScanResults( List<ScanResult> _results ) {
            for( ScanResult result: _results ) {
                addScanResult( result );
            }
        }

        @Override
        public void onScanFailed( int _error ) {
            Log.e( TAG, "BLE scan failed with code " +_error );
        }

        /*
        Add scan result
         */
        private void addScanResult( ScanResult _result ) {
            // get scanned device
            BluetoothDevice device= _result.getDevice();
            // get scanned device MAC address
            String device_address= device.getAddress();
            // add the device to the result list
            cb_scan_results_.put( device_address, device );
            // log
            Log.d( TAG, "scan results device: " + device );
            tv_status_.setText( "add scanned device: " + device_address );
        }
    }
}